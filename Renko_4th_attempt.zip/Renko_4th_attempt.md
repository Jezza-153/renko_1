```python
# Renko Chart Analysis with Stochastic Oscillator

#This notebook builds a Renko chart from historical OHLC data, calculates technical indicators, and generates buy/sell signals based on renko bricks .
    
```


```python
## 1. Import Libraries
import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
```


```python
## 2. Configuration Parameters
# Ticker and date range
ticker = 'ES=F'
start_date = '2025-2-01'
end_date = '2026-2-1'

# Renko brick size
brick_size = 15  # Adjust as needed
```


```python
# Download OHLC data from Yahoo Finance
df = yf.download(ticker, start=start_date, end=end_date)

# Flatten MultiIndex columns (fix for newer yfinance versions)
df.columns = df.columns.get_level_values(0)

# Keep only the essential columns
df = df[['Open', 'High', 'Low', 'Close']]

# Reset index to get Date as a column
df = df.reset_index()

# Display first few rows
df.head()
```

    /var/folders/2v/mkg1tcnj0dsgbn4wspnx8l0h0000gn/T/ipykernel_32160/2983682258.py:2: FutureWarning: YF.download() has changed argument auto_adjust default to True
      df = yf.download(ticker, start=start_date, end=end_date)
    [*********************100%***********************]  1 of 1 completed





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Price</th>
      <th>Date</th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2025-02-03</td>
      <td>5982.25</td>
      <td>6062.00</td>
      <td>5935.50</td>
      <td>6022.25</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2025-02-04</td>
      <td>6069.00</td>
      <td>6069.00</td>
      <td>5987.00</td>
      <td>6063.00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2025-02-05</td>
      <td>6042.75</td>
      <td>6092.00</td>
      <td>6020.25</td>
      <td>6086.50</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2025-02-06</td>
      <td>6090.25</td>
      <td>6108.50</td>
      <td>6070.00</td>
      <td>6106.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2025-02-07</td>
      <td>6089.75</td>
      <td>6123.25</td>
      <td>6041.25</td>
      <td>6049.50</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Convert Close prices and dates to lists
prices = df['Close'].values.flatten().tolist()
dates = df['Date'].tolist()

renko_data = []      # Stores price levels of each brick
directions = []      # 1 = up, -1 = down, 0 = neutral (first brick)
renko_dates = []     # Stores the date when each brick was formed

last_price = prices[0]
renko_data.append(last_price)
directions.append(0)
renko_dates.append(dates[0])

for idx, price in enumerate(prices):
    diff = price - last_price
    brick_moves = int(diff / brick_size)

    while brick_moves != 0:
        if brick_moves > 0:
            last_price += brick_size
            renko_data.append(last_price)
            directions.append(1)
            renko_dates.append(dates[idx])
            brick_moves -= 1
        elif brick_moves < 0:
            last_price -= brick_size
            renko_data.append(last_price)
            directions.append(-1)
            renko_dates.append(dates[idx])
            brick_moves += 1

print(f"Total Renko bricks: {len(renko_data)}")
print(f"Date range: {renko_dates[0]} to {renko_dates[-1]}")
```

    Total Renko bricks: 634
    Date range: 2025-02-03 00:00:00 to 2026-01-30 00:00:00



```python
## 5. Calculate X and Y Positions for Bricks
x_positions = [0]
y_positions = [renko_data[0]]

for i in range(1, len(renko_data)):
    prev_x = x_positions[-1]
    prev_y = y_positions[-1]
    
    if renko_data[i] > renko_data[i-1]:
        x_positions.append(prev_x + 1)
        y_positions.append(prev_y + brick_size)
    else:
        x_positions.append(prev_x + 1)
        y_positions.append(prev_y - brick_size)
```


```python
# Create DataFrame for Renko data
renko_df = pd.DataFrame({
    'X': x_positions,
    'Y': y_positions,
    'Price': renko_data,
    'Direction': directions,
    'Date': renko_dates
})

# Convert Date to datetime if not already
renko_df['Date'] = pd.to_datetime(renko_df['Date'])

# Calculate Moving Averages
renko_df['MA7'] = renko_df['Price'].rolling(window=7).mean()
renko_df['MA20'] = renko_df['Price'].rolling(window=20).mean()
renko_df['MA200'] = renko_df['Price'].rolling(window=200).mean()

# Calculate Stochastic Oscillator (10, 3, 3)
k_period = 10
d_period = 3
smooth_k = 3

renko_df['Lowest'] = renko_df['Price'].rolling(window=k_period).min()
renko_df['Highest'] = renko_df['Price'].rolling(window=k_period).max()
renko_df['%K'] = 100 * (renko_df['Price'] - renko_df['Lowest']) / (renko_df['Highest'] - renko_df['Lowest'])
renko_df['%K'] = renko_df['%K'].rolling(window=smooth_k).mean()
renko_df['%D'] = renko_df['%K'].rolling(window=d_period).mean()

# Store previous values for crossover detection
renko_df['%K_prev'] = renko_df['%K'].shift(1)
renko_df['%D_prev'] = renko_df['%D'].shift(1)
renko_df['Price_prev'] = renko_df['Price'].shift(1)
renko_df['MA7_prev'] = renko_df['MA7'].shift(1)

# Initialize Signal columns
renko_df['Signal'] = 0
renko_df['Exit_Signal'] = 0

# Display data availability info
first_valid_ma200 = renko_df['MA200'].first_valid_index()
print(f"Total Renko Bricks: {len(renko_df)}")
print(f"MA200 available from brick: {first_valid_ma200}")
print(f"Bricks available for trading: {len(renko_df) - first_valid_ma200}")
print(f"Date range: {renko_df['Date'].min().strftime('%Y-%m-%d')} to {renko_df['Date'].max().strftime('%Y-%m-%d')}")

renko_df.head(15)
```

    Total Renko Bricks: 634
    MA200 available from brick: 199
    Bricks available for trading: 435
    Date range: 2025-02-03 to 2026-01-30





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>X</th>
      <th>Y</th>
      <th>Price</th>
      <th>Direction</th>
      <th>Date</th>
      <th>MA7</th>
      <th>MA20</th>
      <th>MA200</th>
      <th>Lowest</th>
      <th>Highest</th>
      <th>%K</th>
      <th>%D</th>
      <th>%K_prev</th>
      <th>%D_prev</th>
      <th>Price_prev</th>
      <th>MA7_prev</th>
      <th>Signal</th>
      <th>Exit_Signal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>6022.25</td>
      <td>6022.25</td>
      <td>0</td>
      <td>2025-02-03</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>6037.25</td>
      <td>6037.25</td>
      <td>1</td>
      <td>2025-02-04</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6022.25</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>6052.25</td>
      <td>6052.25</td>
      <td>1</td>
      <td>2025-02-04</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6037.25</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>6067.25</td>
      <td>6067.25</td>
      <td>1</td>
      <td>2025-02-05</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6052.25</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>6082.25</td>
      <td>6082.25</td>
      <td>1</td>
      <td>2025-02-05</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6067.25</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>6097.25</td>
      <td>6097.25</td>
      <td>1</td>
      <td>2025-02-06</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6082.25</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>6082.25</td>
      <td>6082.25</td>
      <td>-1</td>
      <td>2025-02-07</td>
      <td>6062.964286</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6097.25</td>
      <td>NaN</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>6067.25</td>
      <td>6067.25</td>
      <td>-1</td>
      <td>2025-02-07</td>
      <td>6069.392857</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6082.25</td>
      <td>6062.964286</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>6052.25</td>
      <td>6052.25</td>
      <td>-1</td>
      <td>2025-02-07</td>
      <td>6071.535714</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6067.25</td>
      <td>6069.392857</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>6067.25</td>
      <td>6067.25</td>
      <td>1</td>
      <td>2025-02-10</td>
      <td>6073.678571</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6022.25</td>
      <td>6097.25</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6052.25</td>
      <td>6071.535714</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10</td>
      <td>6082.25</td>
      <td>6082.25</td>
      <td>1</td>
      <td>2025-02-10</td>
      <td>6075.821429</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6037.25</td>
      <td>6097.25</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6067.25</td>
      <td>6073.678571</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>11</td>
      <td>6097.25</td>
      <td>6097.25</td>
      <td>1</td>
      <td>2025-02-13</td>
      <td>6077.964286</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6052.25</td>
      <td>6097.25</td>
      <td>78.333333</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6082.25</td>
      <td>6075.821429</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>12</td>
      <td>6112.25</td>
      <td>6112.25</td>
      <td>1</td>
      <td>2025-02-13</td>
      <td>6080.107143</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6052.25</td>
      <td>6112.25</td>
      <td>91.666667</td>
      <td>NaN</td>
      <td>78.333333</td>
      <td>NaN</td>
      <td>6097.25</td>
      <td>6077.964286</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>13</td>
      <td>6127.25</td>
      <td>6127.25</td>
      <td>1</td>
      <td>2025-02-13</td>
      <td>6086.535714</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6052.25</td>
      <td>6127.25</td>
      <td>100.000000</td>
      <td>90.000000</td>
      <td>91.666667</td>
      <td>NaN</td>
      <td>6112.25</td>
      <td>6080.107143</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>14</td>
      <td>6142.25</td>
      <td>6142.25</td>
      <td>1</td>
      <td>2025-02-18</td>
      <td>6097.250000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6052.25</td>
      <td>6142.25</td>
      <td>100.000000</td>
      <td>97.222222</td>
      <td>100.000000</td>
      <td>90.0</td>
      <td>6127.25</td>
      <td>6086.535714</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
## 7. Define Parameters and Generate Buy/Sell Signals Based on Renko Bricks
# Trading Parameters
initial_capital = 10000
risk_per_trade = 0.01   # 1% risk
position_size = 1       # We'll adjust this later

capital = initial_capital
equity_curve = []
trade_log = []
```


```python
### 7.1 Generate Trade Signals on Full Dataset (Long & Short Strategy)

#**Strategy Rules:**
#- **Long Entry:** Green brick above MA200 AND %K crosses above %D
#- **Long Exit:** Price crosses below MA7
#- **Short Entry:** Red brick below MA200 AND %K crosses below %D
#- **Short Exit:** Price crosses above MA7
# Reset trading parameters
capital = initial_capital
equity_curve = []
trade_log = []
daily_pnl = []  # Track daily PnL (change in equity per brick)
cumulative_pnl = []  # Track cumulative PnL

# Position tracking
in_long = False
in_short = False
entry_price = 0
position_size = 0
risk_amount = 0

# Signal counters
long_entry_count = 0
short_entry_count = 0
long_exit_count = 0
short_exit_count = 0

running_pnl = 0
previous_capital = initial_capital

for i in range(1, len(renko_df)):
    current_price = renko_df.loc[i, 'Price']
    prev_price = renko_df.loc[i, 'Price_prev']
    ma7 = renko_df.loc[i, 'MA7']
    ma7_prev = renko_df.loc[i, 'MA7_prev']
    ma200 = renko_df.loc[i, 'MA200']
    direction = renko_df.loc[i, 'Direction']
    current_date = renko_df.loc[i, 'Date']
    
    # Get stochastic values
    k_current = renko_df.loc[i, '%K']
    k_prev = renko_df.loc[i, '%K_prev']
    d_current = renko_df.loc[i, '%D']
    d_prev = renko_df.loc[i, '%D_prev']
    
    # Skip if any required values are NaN
    if pd.isna(ma200) or pd.isna(ma7) or pd.isna(k_prev) or pd.isna(d_prev):
        equity_curve.append(capital)
        daily_pnl.append(0)  # No change
        cumulative_pnl.append(running_pnl)
        previous_capital = capital
        continue
    
    # Detect stochastic crossovers
    stoch_cross_up = (k_prev < d_prev) and (k_current > d_current)
    stoch_cross_down = (k_prev > d_prev) and (k_current < d_current)
    
    # Track PnL for this brick
    brick_pnl = 0
    
    # ========== EXIT LOGIC (Check exits first) ==========
    
    # Exit Long: Price crosses below MA7
    if in_long:
        if prev_price >= ma7_prev and current_price < ma7:
            exit_price = current_price
            pnl = (exit_price - entry_price) * position_size
            capital += pnl
            running_pnl += pnl
            brick_pnl = pnl
            in_long = False
            long_exit_count += 1
            renko_df.loc[i, 'Exit_Signal'] = 1
            
            rr_ratio = pnl / risk_amount if risk_amount != 0 else 0
            
            trade_log[-1].update({
                'Exit_Brick': i,
                'Exit_Price': exit_price,
                'Exit_Date': current_date,
                'PnL': pnl,
                'Capital': capital,
                'Risk_Amount': risk_amount,
                'RR_Ratio': rr_ratio
            })
    
    # Exit Short: Price crosses above MA7
    if in_short:
        if prev_price <= ma7_prev and current_price > ma7:
            exit_price = current_price
            pnl = (entry_price - exit_price) * position_size
            capital += pnl
            running_pnl += pnl
            brick_pnl = pnl
            in_short = False
            short_exit_count += 1
            renko_df.loc[i, 'Exit_Signal'] = -1
            
            rr_ratio = pnl / risk_amount if risk_amount != 0 else 0
            
            trade_log[-1].update({
                'Exit_Brick': i,
                'Exit_Price': exit_price,
                'Exit_Date': current_date,
                'PnL': pnl,
                'Capital': capital,
                'Risk_Amount': risk_amount,
                'RR_Ratio': rr_ratio
            })
    
    # ========== ENTRY LOGIC ==========
    
    if not in_long and not in_short:
        
        # Long Entry: Green brick above MA200 AND %K crosses above %D
        if direction == 1 and current_price > ma200 and stoch_cross_up:
            entry_price = current_price
            risk_amount = capital * risk_per_trade
            position_size = risk_amount / brick_size
            in_long = True
            long_entry_count += 1
            renko_df.loc[i, 'Signal'] = 1
            trade_log.append({
                'Type': 'LONG',
                'Entry_Brick': i,
                'Entry_Price': entry_price,
                'Entry_Date': current_date,
                'Size': position_size,
                'Risk_Amount': risk_amount
            })
        
        # Short Entry: Red brick below MA200 AND %K crosses below %D
        elif direction == -1 and current_price < ma200 and stoch_cross_down:
            entry_price = current_price
            risk_amount = capital * risk_per_trade
            position_size = risk_amount / brick_size
            in_short = True
            short_entry_count += 1
            renko_df.loc[i, 'Signal'] = -1
            trade_log.append({
                'Type': 'SHORT',
                'Entry_Brick': i,
                'Entry_Price': entry_price,
                'Entry_Date': current_date,
                'Size': position_size,
                'Risk_Amount': risk_amount
            })
    
    # Calculate daily PnL (change from previous capital)
    daily_change = capital - previous_capital
    daily_pnl.append(daily_change)
    
    equity_curve.append(capital)
    cumulative_pnl.append(running_pnl)
    previous_capital = capital

# Close any open positions at the end
if in_long:
    exit_price = renko_df.loc[len(renko_df) - 1, 'Price']
    pnl = (exit_price - entry_price) * position_size
    capital += pnl
    running_pnl += pnl
    long_exit_count += 1
    rr_ratio = pnl / risk_amount if risk_amount != 0 else 0
    trade_log[-1].update({
        'Exit_Brick': len(renko_df) - 1,
        'Exit_Price': exit_price,
        'Exit_Date': renko_df.loc[len(renko_df) - 1, 'Date'],
        'PnL': pnl,
        'Capital': capital,
        'Risk_Amount': risk_amount,
        'RR_Ratio': rr_ratio,
        'Note': 'Closed at end'
    })
    if equity_curve:
        equity_curve[-1] = capital
        daily_pnl[-1] = pnl
        cumulative_pnl[-1] = running_pnl

if in_short:
    exit_price = renko_df.loc[len(renko_df) - 1, 'Price']
    pnl = (entry_price - exit_price) * position_size
    capital += pnl
    running_pnl += pnl
    short_exit_count += 1
    rr_ratio = pnl / risk_amount if risk_amount != 0 else 0
    trade_log[-1].update({
        'Exit_Brick': len(renko_df) - 1,
        'Exit_Price': exit_price,
        'Exit_Date': renko_df.loc[len(renko_df) - 1, 'Date'],
        'PnL': pnl,
        'Capital': capital,
        'Risk_Amount': risk_amount,
        'RR_Ratio': rr_ratio,
        'Note': 'Closed at end'
    })
    if equity_curve:
        equity_curve[-1] = capital
        daily_pnl[-1] = pnl
        cumulative_pnl[-1] = running_pnl

# Display signal counts
print("=" * 50)
print("           TRADE SIGNAL SUMMARY")
print("=" * 50)
print(f"Long Entry Signals:  {long_entry_count}")
print(f"Long Exit Signals:   {long_exit_count}")
print(f"Short Entry Signals: {short_entry_count}")
print(f"Short Exit Signals:  {short_exit_count}")
print("-" * 50)
print(f"Total Trades Executed: {len(trade_log)}")
print(f"  - Long Trades:  {len([t for t in trade_log if t['Type'] == 'LONG'])}")
print(f"  - Short Trades: {len([t for t in trade_log if t['Type'] == 'SHORT'])}")
print("=" * 50)
```
## 8. Calculate Performance Metrics (Full Dataset)

#Includes:
#- Basic metrics (Return, Sharpe, Drawdown)
#- Win/Loss streaks
#- Risk-Reward ratios
#- Value at Risk (VaR)

# Ensure equity_curve has values
if len(equity_curve) == 0:
    equity_curve = [initial_capital]
if len(cumulative_pnl) == 0:
    cumulative_pnl = [0]

# Convert to numpy arrays
equity_array = np.array(equity_curve)
cumulative_pnl_array = np.array(cumulative_pnl)

# ========== BASIC METRICS ==========

# Returns (simple)
if len(equity_array) > 1:
    returns = np.diff(equity_array) / np.where(equity_array[:-1] != 0, equity_array[:-1], 1)
else:
    returns = np.array([0])

# Sharpe Ratio (annualized)
sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) != 0 else 0

# Max Drawdown
running_max = np.maximum.accumulate(equity_array)
drawdown = np.where(running_max != 0, (equity_array - running_max) / running_max, 0)
max_drawdown = drawdown.min()

# Total Return
total_return = (capital - initial_capital) / initial_capital

# ========== WIN/LOSS STREAKS ==========

def calculate_streaks(trade_log):
    """Calculate maximum winning and losing streaks"""
    if not trade_log:
        return 0, 0
    
    results = [1 if t.get('PnL', 0) > 0 else (-1 if t.get('PnL', 0) < 0 else 0) 
               for t in trade_log if 'PnL' in t]
    
    if not results:
        return 0, 0
    
    max_win_streak = 0
    max_loss_streak = 0
    current_win_streak = 0
    current_loss_streak = 0
    
    for result in results:
        if result == 1:  # Win
            current_win_streak += 1
            current_loss_streak = 0
            max_win_streak = max(max_win_streak, current_win_streak)
        elif result == -1:  # Loss
            current_loss_streak += 1
            current_win_streak = 0
            max_loss_streak = max(max_loss_streak, current_loss_streak)
        else:  # Break-even
            current_win_streak = 0
            current_loss_streak = 0
    
    return max_win_streak, max_loss_streak

max_win_streak, max_loss_streak = calculate_streaks(trade_log)

# ========== RISK-REWARD RATIOS ==========

# Get R:R ratios for winning and losing trades
winning_rr = [t['RR_Ratio'] for t in trade_log if 'RR_Ratio' in t and t.get('PnL', 0) > 0]
losing_rr = [t['RR_Ratio'] for t in trade_log if 'RR_Ratio' in t and t.get('PnL', 0) < 0]

avg_winning_rr = np.mean(winning_rr) if winning_rr else 0
avg_losing_rr = np.mean(losing_rr) if losing_rr else 0  # This will be negative

# ========== TRADE STATISTICS ==========

# Separate Long and Short trades
long_trades = [t for t in trade_log if t['Type'] == 'LONG' and 'PnL' in t]
short_trades = [t for t in trade_log if t['Type'] == 'SHORT' and 'PnL' in t]

# Overall Win Rate
wins = [t['PnL'] for t in trade_log if 'PnL' in t and t['PnL'] > 0]
losses = [t['PnL'] for t in trade_log if 'PnL' in t and t['PnL'] < 0]
win_rate = len(wins) / len(trade_log) if trade_log else 0

# Long Win Rate
long_wins = [t['PnL'] for t in long_trades if t['PnL'] > 0]
long_win_rate = len(long_wins) / len(long_trades) if long_trades else 0

# Short Win Rate
short_wins = [t['PnL'] for t in short_trades if t['PnL'] > 0]
short_win_rate = len(short_wins) / len(short_trades) if short_trades else 0

# Profit Factor
profit_factor = sum(wins) / abs(sum(losses)) if losses else np.inf

# Average Win/Loss
avg_win = np.mean(wins) if wins else 0
avg_loss = np.mean(losses) if losses else 0

# ========== PRINT METRICS ==========

print("=" * 60)
print("      STRATEGY PERFORMANCE METRICS (FULL DATASET)")
print("=" * 60)
print(f"Initial Capital:        ${initial_capital:,.2f}")
print(f"Final Capital:          ${capital:,.2f}")
print(f"Total Return:           {total_return:.2%}")
print(f"Sharpe Ratio:           {sharpe_ratio:.2f}")
print(f"Max Drawdown:           {max_drawdown:.2%}")
print("-" * 60)
print(f"Total Trades:           {len(trade_log)}")
print(f"  - Long Trades:        {len(long_trades)}")
print(f"  - Short Trades:       {len(short_trades)}")
print("-" * 60)
print(f"Overall Win Rate:       {win_rate:.2%}")
print(f"Long Win Rate:          {long_win_rate:.2%}")
print(f"Short Win Rate:         {short_win_rate:.2%}")
print(f"Profit Factor:          {profit_factor:.2f}")
print("-" * 60)
print(f"Average Win:            ${avg_win:,.2f}")
print(f"Average Loss:           ${avg_loss:,.2f}")
print("-" * 60)
print("              STREAK ANALYSIS")
print("-" * 60)
print(f"Max Winning Streak:     {max_win_streak} trades")
print(f"Max Losing Streak:      {max_loss_streak} trades")
print("-" * 60)
print("            RISK-REWARD ANALYSIS")
print("-" * 60)
print(f"Avg Winning Trade R:R:  {avg_winning_rr:.2f}R")
print(f"Avg Losing Trade R:R:   {avg_losing_rr:.2f}R")
print("=" * 60)

## 9. Calculate and Plot 10-Period Rolling Value at Risk (VaR)

##**VaR Calculation:**
##- VaR (99%) = Standard Deviation of Daily PnL × 2.33
##- Rolling window: 10 periods

##**Chart Elements:**
##- Red X markers: Daily PnL values
##- Orange line: 10-day rolling VaR (positive)
##- Grey line: Negative 10-day rolling VaR
##- Red dashed line: -30% of current total equity (risk threshold)


# Create DataFrame for VaR analysis
var_df = pd.DataFrame({
    'Brick': range(1, len(daily_pnl) + 1),
    'Daily_PnL': daily_pnl
})

# Get dates for the VaR dataframe
var_dates = renko_df['Date'].iloc[1:len(daily_pnl) + 1].reset_index(drop=True)
if len(var_dates) < len(var_df):
    var_dates = pd.concat([var_dates, pd.Series([renko_df['Date'].iloc[-1]] * (len(var_df) - len(var_dates)))]).reset_index(drop=True)
var_df['Date'] = var_dates

# Calculate 10-period rolling standard deviation of DAILY PnL
var_df['Rolling_StdDev'] = var_df['Daily_PnL'].rolling(window=10).std()

# Calculate VaR at 99% confidence level (2.33 standard deviations)
# VaR = Rolling StdDev of Daily PnL * 2.33
var_df['VaR_99'] = var_df['Rolling_StdDev'] * 2.33

# Calculate negative VaR (for lower bound)
var_df['Neg_VaR_99'] = -var_df['VaR_99']

# Calculate -30% of current total equity (risk threshold)
equity_threshold = -0.30 * capital

# Print VaR statistics
print("=" * 65)
print("       10-PERIOD ROLLING VALUE AT RISK (VaR) - DAILY PnL")
print("=" * 65)
print(f"VaR Confidence Level:     99% (2.33 standard deviations)")
print(f"Rolling Window:           10 periods")
print(f"Calculation:              STDEV(Daily PnL) × 2.33")
print("-" * 65)
current_var = var_df['VaR_99'].iloc[-1]
max_var = var_df['VaR_99'].max()
avg_var = var_df['VaR_99'].mean()
print(f"Current VaR (99%):        ${current_var:,.2f}" if not pd.isna(current_var) else "Current VaR (99%):        N/A")
print(f"Max VaR (99%):            ${max_var:,.2f}" if not pd.isna(max_var) else "Max VaR (99%):            N/A")
print(f"Avg VaR (99%):            ${avg_var:,.2f}" if not pd.isna(avg_var) else "Avg VaR (99%):            N/A")
print("-" * 65)
print(f"Current Total Equity:     ${capital:,.2f}")
print(f"-30% Equity Threshold:    ${equity_threshold:,.2f}")
print("=" * 65)

# ========== PLOT VaR CHART ==========

fig, ax = plt.subplots(figsize=(18, 8))

# X-axis values (brick numbers)
x_values = var_df['Brick'].values

# Plot Daily PnL as red X markers
ax.scatter(x_values, var_df['Daily_PnL'], marker='x', color='red', s=50, 
           label='Daily PnL', zorder=3, alpha=0.7)

# Plot 10-day Rolling VaR (positive) as orange line
ax.plot(x_values, var_df['VaR_99'], color='orange', linewidth=2, 
        label='10-Day Rolling VaR (99%)', zorder=2)

# Plot Negative 10-day Rolling VaR as grey line
ax.plot(x_values, var_df['Neg_VaR_99'], color='grey', linewidth=2, 
        label='Negative VaR (99%)', zorder=2)

# Plot -30% Equity Threshold as red dashed line
ax.axhline(y=equity_threshold, color='red', linestyle='--', linewidth=2, 
           label=f'-30% Equity Threshold (${equity_threshold:,.2f})')

# Add zero line for reference
ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5, alpha=0.5)

# Fill between VaR lines (optional visual)
ax.fill_between(x_values, var_df['VaR_99'], var_df['Neg_VaR_99'], 
                color='orange', alpha=0.1, label='VaR Range')

# Formatting
ax.set_title('10-Period Rolling Value at Risk (VaR) Based on Daily PnL\n'
             f'Period: {var_df["Date"].min().strftime("%Y-%m-%d")} to {var_df["Date"].max().strftime("%Y-%m-%d")}',
             fontsize=14)
ax.set_xlabel('Brick Number')
ax.set_ylabel('Value ($)')
ax.legend(loc='upper left', fontsize=10)
ax.grid(True, alpha=0.3)

# Add secondary x-axis with dates
ax2 = ax.twiny()
num_ticks = 12
tick_indices = np.linspace(0, len(var_df) - 1, num_ticks, dtype=int)
ax2.set_xlim(ax.get_xlim())
ax2.set_xticks([x_values[i] for i in tick_indices])
ax2.set_xticklabels([var_df.loc[i, 'Date'].strftime('%m/%d/%y') for i in tick_indices], fontsize=9)
ax2.set_xlabel('Date', fontsize=10)

plt.tight_layout()
plt.show()

## 10. Alternative VaR Chart with Date X-Axis
# Create a cleaner version with Date on X-axis

fig, ax = plt.subplots(figsize=(18, 8))

# Use dates for x-axis
x_dates = var_df['Date']

# Plot Daily PnL as red X markers
ax.scatter(x_dates, var_df['Daily_PnL'], marker='x', color='red', s=60, 
           label='Daily PnL', zorder=3, alpha=0.8)

# Plot 10-day Rolling VaR (positive) as orange line
ax.plot(x_dates, var_df['VaR_99'], color='orange', linewidth=2.5, 
        label='10-Day Rolling VaR (99%)', zorder=2)

# Plot Negative 10-day Rolling VaR as grey line
ax.plot(x_dates, var_df['Neg_VaR_99'], color='grey', linewidth=2.5, 
        label='Negative VaR (99%)', zorder=2)

# Plot -30% Equity Threshold as red dashed line
ax.axhline(y=equity_threshold, color='red', linestyle='--', linewidth=2.5, 
           label=f'-30% Equity Threshold (${equity_threshold:,.2f})')

# Add zero line for reference
ax.axhline(y=0, color='black', linestyle='-', linewidth=1, alpha=0.5)

# Fill between VaR lines
ax.fill_between(x_dates, var_df['VaR_99'], var_df['Neg_VaR_99'], 
                color='orange', alpha=0.1)

# Highlight breaches (when daily PnL exceeds VaR bounds)
breaches_high = var_df[var_df['Daily_PnL'] > var_df['VaR_99']]
breaches_low = var_df[var_df['Daily_PnL'] < var_df['Neg_VaR_99']]

if len(breaches_high) > 0:
    ax.scatter(breaches_high['Date'], breaches_high['Daily_PnL'], 
               marker='o', color='green', s=100, edgecolors='black', 
               label=f'VaR Breach (Positive): {len(breaches_high)}', zorder=4)

if len(breaches_low) > 0:
    ax.scatter(breaches_low['Date'], breaches_low['Daily_PnL'], 
               marker='o', color='darkred', s=100, edgecolors='black', 
               label=f'VaR Breach (Negative): {len(breaches_low)}', zorder=4)

# Formatting
ax.set_title('10-Period Rolling Value at Risk (VaR) Based on Daily PnL\n'
             f'VaR = STDEV(Daily PnL) × 2.33 | Current Equity: ${capital:,.2f}',
             fontsize=14)
ax.set_xlabel('Date', fontsize=12)
ax.set_ylabel('Value ($)', fontsize=12)
ax.legend(loc='best', fontsize=9)
ax.grid(True, alpha=0.3)

# Format x-axis dates
plt.gcf().autofmt_xdate()

plt.tight_layout()
plt.show()

# Print VaR breach statistics
print("\n" + "=" * 50)
print("           VaR BREACH ANALYSIS")
print("=" * 50)
print(f"Total Daily PnL Observations:  {len(var_df)}")
print(f"VaR Breaches (Positive):       {len(breaches_high)}")
print(f"VaR Breaches (Negative):       {len(breaches_low)}")
print(f"Breach Rate:                   {(len(breaches_high) + len(breaches_low)) / len(var_df) * 100:.2f}%")
print(f"Expected Breach Rate (99%):    1.00%")
print("=" * 50)

## 11. Daily PnL Distribution Analysis

# Analyze Daily PnL distribution
fig, axes = plt.subplots(1, 2, figsize=(16, 5))

# Filter non-zero daily PnL values
non_zero_pnl = var_df[var_df['Daily_PnL'] != 0]['Daily_PnL']

# Histogram of Daily PnL
if len(non_zero_pnl) > 0:
    axes[0].hist(non_zero_pnl, bins=30, color='steelblue', alpha=0.7, edgecolor='black')
    axes[0].axvline(x=0, color='red', linestyle='--', linewidth=2, label='Zero')
    axes[0].axvline(x=non_zero_pnl.mean(), color='green', linestyle='-', linewidth=2, 
                    label=f'Mean: ${non_zero_pnl.mean():,.2f}')
    axes[0].axvline(x=current_var, color='orange', linestyle='--', linewidth=2, 
                    label=f'VaR (99%): ${current_var:,.2f}')
    axes[0].axvline(x=-current_var, color='grey', linestyle='--', linewidth=2, 
                    label=f'-VaR (99%): ${-current_var:,.2f}')
    axes[0].set_title('Distribution of Daily PnL (Non-Zero)', fontsize=12)
    axes[0].set_xlabel('Daily PnL ($)')
    axes[0].set_ylabel('Frequency')
    axes[0].legend(fontsize=9)
    axes[0].grid(True, alpha=0.3)

# Box plot of Daily PnL by trade type
if trade_log:
    trade_pnls = {'LONG': [], 'SHORT': []}
    for trade in trade_log:
        if 'PnL' in trade:
            trade_pnls[trade['Type']].append(trade['PnL'])
    
    # Prepare data for box plot
    box_data = []
    box_labels = []
    for trade_type, pnls in trade_pnls.items():
        if pnls:
            box_data.append(pnls)
            box_labels.append(f"{trade_type}\n(n={len(pnls)})")
    
    if box_data:
        bp = axes[1].boxplot(box_data, labels=box_labels, patch_artist=True)
        colors = ['lightgreen', 'lightcoral']
        for patch, color in zip(bp['boxes'], colors[:len(box_data)]):
            patch.set_facecolor(color)
        axes[1].axhline(y=0, color='red', linestyle='--', linewidth=1)
        axes[1].set_title('PnL Distribution by Trade Type', fontsize=12)
        axes[1].set_ylabel('PnL ($)')
        axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# Print Daily PnL statistics
print("\n" + "=" * 50)
print("           DAILY PnL STATISTICS")
print("=" * 50)
print(f"Total Observations:     {len(var_df)}")
print(f"Non-Zero PnL Days:      {len(non_zero_pnl)}")
print(f"Mean Daily PnL:         ${non_zero_pnl.mean():,.2f}" if len(non_zero_pnl) > 0 else "Mean Daily PnL: N/A")
print(f"Std Dev Daily PnL:      ${non_zero_pnl.std():,.2f}" if len(non_zero_pnl) > 0 else "Std Dev Daily PnL: N/A")
print(f"Max Daily Gain:         ${non_zero_pnl.max():,.2f}" if len(non_zero_pnl) > 0 else "Max Daily Gain: N/A")
print(f"Max Daily Loss:         ${non_zero_pnl.min():,.2f}" if len(non_zero_pnl) > 0 else "Max Daily Loss: N/A")
print("=" * 50)## 9. Plot Renko Chart with Trades (Full Dataset)

# Setup the plot with two subplots: one for Renko, one for Stochastic
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(24, 18), gridspec_kw={'height_ratios': [3, 1]})

# ------------------------------------
# Subplot 1: Renko Chart with Trades
# ------------------------------------

ax1.set_title(f"Renko Chart for {ticker} (FULL DATASET) | Brick Size: {brick_size}\n"
              f"Strategy: Long above MA200 + Stoch Cross Up | Short below MA200 + Stoch Cross Down | Exit at MA7 Cross\n"
              f"Period: {renko_df['Date'].min().strftime('%Y-%m-%d')} to {renko_df['Date'].max().strftime('%Y-%m-%d')}",
              fontsize=14)
ax1.set_xlabel('Brick Number / Date')
ax1.set_ylabel('Price')

# Plot each brick
for i in range(len(x_positions)):
    color = 'green' if directions[i] == 1 else 'red'
    rect = Rectangle(
        (x_positions[i], y_positions[i]), 1, brick_size,
        facecolor=color, edgecolor='black'
    )
    ax1.add_patch(rect)

# Plot Moving Averages
ax1.plot(x_positions, renko_df['MA7'].tolist(), color='orange', linewidth=2, label='MA 7')
ax1.plot(x_positions, renko_df['MA200'].tolist(), color='blue', linewidth=2, label='MA 200')

# Plot Long Entry Points
long_entries = [t for t in trade_log if t['Type'] == 'LONG']
long_entry_bricks = [t['Entry_Brick'] for t in long_entries]
long_entry_prices = [t['Entry_Price'] for t in long_entries]

if long_entry_bricks:
    ax1.scatter(long_entry_bricks, long_entry_prices, marker='^', color='lime', s=200,
                edgecolors='black', linewidths=1.5, label='Long Entry', zorder=5)

# Plot Short Entry Points
short_entries = [t for t in trade_log if t['Type'] == 'SHORT']
short_entry_bricks = [t['Entry_Brick'] for t in short_entries]
short_entry_prices = [t['Entry_Price'] for t in short_entries]

if short_entry_bricks:
    ax1.scatter(short_entry_bricks, short_entry_prices, marker='v', color='magenta', s=200,
                edgecolors='black', linewidths=1.5, label='Short Entry', zorder=5)

# Plot Exit Points
exit_bricks = [t['Exit_Brick'] for t in trade_log if 'Exit_Brick' in t]
exit_prices = [t['Exit_Price'] for t in trade_log if 'Exit_Price' in t]

if exit_bricks:
    ax1.scatter(exit_bricks, exit_prices, marker='x', color='yellow', s=200,
                linewidths=3, label='Exit', zorder=5)

# Draw lines connecting entry to exit
for trade in trade_log:
    if 'Exit_Brick' in trade:
        pnl = trade.get('PnL', 0)
        line_color = 'cyan' if pnl > 0 else 'orange'
        ax1.plot([trade['Entry_Brick'], trade['Exit_Brick']],
                 [trade['Entry_Price'], trade['Exit_Price']],
                 color=line_color, linestyle='--', linewidth=2, alpha=0.8)

# Add date annotations for trades
for trade in trade_log:
    entry_date = trade.get('Entry_Date')
    if entry_date:
        ax1.annotate(entry_date.strftime('%m/%d'),
                     (trade['Entry_Brick'], trade['Entry_Price']),
                     textcoords="offset points", xytext=(0, 15),
                     fontsize=7, ha='center', color='black',
                     bbox=dict(boxstyle='round,pad=0.2', facecolor='white', alpha=0.7))

# Set axis limits
ax1.set_xlim(-1, max(x_positions) + 2)
ax1.set_ylim(min(y_positions) - brick_size * 3, max(y_positions) + brick_size * 4)

# Create custom x-axis with dates
# Show date labels at regular intervals
num_ticks = 15
tick_indices = np.linspace(0, len(x_positions) - 1, num_ticks, dtype=int)
tick_labels = [f"{x_positions[i]}\n{renko_df.loc[i, 'Date'].strftime('%m/%d/%y')}" for i in tick_indices]
ax1.set_xticks([x_positions[i] for i in tick_indices])
ax1.set_xticklabels(tick_labels, fontsize=8)

# Y-axis ticks
min_price = min(y_positions)
max_price = max(y_positions)
y_tick_step = max(1, int((max_price - min_price) / brick_size / 20))
ax1.set_yticks([min_price + i * brick_size * y_tick_step
                for i in range(int((max_price - min_price) / (brick_size * y_tick_step)) + 3)])

ax1.grid(True, alpha=0.3)
ax1.legend(loc='upper left', fontsize=10)

# -------------------
# Subplot 2: Stochastic Oscillator
# -------------------

ax2.set_title("Stochastic Oscillator (10, 3, 3) - Full Dataset", fontsize=14)
ax2.set_xlabel('Brick Number / Date')
ax2.set_ylabel('%K / %D')

ax2.plot(x_positions, renko_df['%K'].tolist(), label='%K', color='orange', linewidth=2)
ax2.plot(x_positions, renko_df['%D'].tolist(), label='%D', color='purple', linewidth=2)

ax2.axhline(80, color='red', linestyle='--', linewidth=1, label='Overbought (80)')
ax2.axhline(20, color='green', linestyle='--', linewidth=1, label='Oversold (20)')

# Mark entry/exit points on stochastic
if long_entry_bricks:
    ax2.scatter(long_entry_bricks, [renko_df.loc[i, '%K'] for i in long_entry_bricks],
                marker='^', color='lime', s=100, edgecolors='black', zorder=5)

if short_entry_bricks:
    ax2.scatter(short_entry_bricks, [renko_df.loc[i, '%K'] for i in short_entry_bricks],
                marker='v', color='magenta', s=100, edgecolors='black', zorder=5)

if exit_bricks:
    ax2.scatter(exit_bricks, [renko_df.loc[i, '%K'] for i in exit_bricks],
                marker='x', color='yellow', s=100, linewidths=2, zorder=5)

ax2.set_xlim(-1, max(x_positions) + 2)
ax2.set_ylim(-10, 110)
ax2.set_xticks([x_positions[i] for i in tick_indices])
ax2.set_xticklabels(tick_labels, fontsize=8)
ax2.legend(loc='upper left')
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

```python
## 10. Plot Equity Curve (Full Dataset)
# Create equity curve dataframe with dates
equity_dates = renko_df['Date'].iloc[1:len(equity_curve)+1].reset_index(drop=True)
if len(equity_dates) < len(equity_curve):
    equity_dates = pd.concat([equity_dates, pd.Series([renko_df['Date'].iloc[-1]] * (len(equity_curve) - len(equity_dates)))]).reset_index(drop=True)

plt.figure(figsize=(16, 6))
plt.plot(equity_dates, equity_curve, label='Equity Curve', color='blue', linewidth=2)
plt.axhline(y=initial_capital, color='gray', linestyle='--', label='Initial Capital')
plt.title('Strategy Equity Curve (Full Dataset) - Long & Short Trades', fontsize=16)
plt.xlabel('Date')
plt.ylabel('Capital ($)')
plt.grid(True, alpha=0.3)
plt.legend()
plt.gcf().autofmt_xdate()
plt.tight_layout()
plt.show()

## 11. Plot Drawdown (Full Dataset)
# Use the same equity_dates from previous cell
drawdown_dates = equity_dates[:len(drawdown)]

plt.figure(figsize=(16, 4))
plt.fill_between(drawdown_dates, drawdown[:len(drawdown_dates)] * 100, color='red', alpha=0.7)
plt.title('Drawdown Over Time (Full Dataset)', fontsize=16)
plt.xlabel('Date')
plt.ylabel('Drawdown (%)')
plt.grid(True, alpha=0.3)
plt.gcf().autofmt_xdate()
plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    



    
![png](output_11_1.png)
    



```python
## 12. Trade Log Summary (Full Dataset)
# Display trade log as DataFrame
if trade_log:
    trade_log_df = pd.DataFrame(trade_log)
    
    # Format dates
    if 'Entry_Date' in trade_log_df.columns:
        trade_log_df['Entry_Date'] = pd.to_datetime(trade_log_df['Entry_Date']).dt.strftime('%Y-%m-%d')
    if 'Exit_Date' in trade_log_df.columns:
        trade_log_df['Exit_Date'] = pd.to_datetime(trade_log_df['Exit_Date']).dt.strftime('%Y-%m-%d')
    
    # Add profit/loss indicator
    trade_log_df['Result'] = trade_log_df['PnL'].apply(
        lambda x: '✅ WIN' if x > 0 else ('❌ LOSS' if x < 0 else '➖ BE') if pd.notna(x) else '⏳ OPEN'
    )
    
    # Format R:R ratio
    if 'RR_Ratio' in trade_log_df.columns:
        trade_log_df['R:R'] = trade_log_df['RR_Ratio'].apply(lambda x: f"{x:.2f}R" if pd.notna(x) else "N/A")
    
    # Reorder columns
    cols = ['Type', 'Entry_Date', 'Entry_Brick', 'Entry_Price', 'Exit_Date', 'Exit_Brick', 
            'Exit_Price', 'Size', 'PnL', 'R:R', 'Capital', 'Result']
    cols = [c for c in cols if c in trade_log_df.columns]
    trade_log_df = trade_log_df[cols]
    
    display(trade_log_df)
    
    # Summary by trade type
    print("\n" + "=" * 60)
    print("              TRADE SUMMARY BY TYPE")
    print("=" * 60)
    
    for trade_type in ['LONG', 'SHORT']:
        type_trades = [t for t in trade_log if t['Type'] == trade_type and 'PnL' in t]
        if type_trades:
            type_pnl = sum(t['PnL'] for t in type_trades)
            type_wins = len([t for t in type_trades if t['PnL'] > 0])
            type_losses = len([t for t in type_trades if t['PnL'] < 0])
            type_win_rr = [t['RR_Ratio'] for t in type_trades if t.get('PnL', 0) > 0 and 'RR_Ratio' in t]
            type_loss_rr = [t['RR_Ratio'] for t in type_trades if t.get('PnL', 0) < 0 and 'RR_Ratio' in t]
            
            print(f"\n{trade_type} Trades:")
            print(f"  Total: {len(type_trades)}")
            print(f"  Wins: {type_wins} | Losses: {type_losses}")
            print(f"  Total PnL: ${type_pnl:,.2f}")
            print(f"  Avg Winning R:R: {np.mean(type_win_rr):.2f}R" if type_win_rr else "  Avg Winning R:R: N/A")
            print(f"  Avg Losing R:R: {np.mean(type_loss_rr):.2f}R" if type_loss_rr else "  Avg Losing R:R: N/A")
        else:
            print(f"\n{trade_type} Trades: None")
    
    # Streak Analysis
    print("\n" + "=" * 60)
    print("              STREAK ANALYSIS")
    print("=" * 60)
    print(f"Maximum Winning Streak: {max_win_streak} consecutive trades")
    print(f"Maximum Losing Streak:  {max_loss_streak} consecutive trades")
    
else:
    print("No trades executed.")
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Type</th>
      <th>Entry_Date</th>
      <th>Entry_Brick</th>
      <th>Entry_Price</th>
      <th>Exit_Date</th>
      <th>Exit_Brick</th>
      <th>Exit_Price</th>
      <th>Size</th>
      <th>PnL</th>
      <th>R:R</th>
      <th>Capital</th>
      <th>Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LONG</td>
      <td>2025-05-08</td>
      <td>276</td>
      <td>5662.25</td>
      <td>2025-05-21</td>
      <td>299</td>
      <td>5947.25</td>
      <td>6.666667</td>
      <td>1900.000000</td>
      <td>19.00R</td>
      <td>11900.000000</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>LONG</td>
      <td>2025-06-06</td>
      <td>323</td>
      <td>5977.25</td>
      <td>2025-06-13</td>
      <td>329</td>
      <td>6007.25</td>
      <td>7.933333</td>
      <td>238.000000</td>
      <td>2.00R</td>
      <td>12138.000000</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>LONG</td>
      <td>2025-06-23</td>
      <td>336</td>
      <td>6022.25</td>
      <td>2025-07-04</td>
      <td>358</td>
      <td>6292.25</td>
      <td>8.092000</td>
      <td>2184.840000</td>
      <td>18.00R</td>
      <td>14322.840000</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LONG</td>
      <td>2025-07-10</td>
      <td>362</td>
      <td>6322.25</td>
      <td>2025-07-15</td>
      <td>364</td>
      <td>6292.25</td>
      <td>9.548560</td>
      <td>-286.456800</td>
      <td>-2.00R</td>
      <td>14036.383200</td>
      <td>❌ LOSS</td>
    </tr>
    <tr>
      <th>4</th>
      <td>LONG</td>
      <td>2025-07-17</td>
      <td>366</td>
      <td>6322.25</td>
      <td>2025-07-31</td>
      <td>374</td>
      <td>6382.25</td>
      <td>9.357589</td>
      <td>561.455328</td>
      <td>4.00R</td>
      <td>14597.838528</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>LONG</td>
      <td>2025-08-22</td>
      <td>405</td>
      <td>6427.25</td>
      <td>2025-08-29</td>
      <td>415</td>
      <td>6487.25</td>
      <td>9.731892</td>
      <td>583.913541</td>
      <td>4.00R</td>
      <td>15181.752069</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>LONG</td>
      <td>2025-09-03</td>
      <td>420</td>
      <td>6442.25</td>
      <td>2025-09-24</td>
      <td>442</td>
      <td>6712.25</td>
      <td>10.121168</td>
      <td>2732.715372</td>
      <td>18.00R</td>
      <td>17914.467442</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>LONG</td>
      <td>2025-09-29</td>
      <td>447</td>
      <td>6697.25</td>
      <td>2025-10-10</td>
      <td>457</td>
      <td>6757.25</td>
      <td>11.942978</td>
      <td>716.578698</td>
      <td>4.00R</td>
      <td>18631.046139</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>LONG</td>
      <td>2025-10-20</td>
      <td>478</td>
      <td>6712.25</td>
      <td>2025-10-22</td>
      <td>484</td>
      <td>6742.25</td>
      <td>12.420697</td>
      <td>372.620923</td>
      <td>2.00R</td>
      <td>19003.667062</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>LONG</td>
      <td>2025-10-23</td>
      <td>486</td>
      <td>6772.25</td>
      <td>2025-10-30</td>
      <td>498</td>
      <td>6892.25</td>
      <td>12.669111</td>
      <td>1520.293365</td>
      <td>8.00R</td>
      <td>20523.960427</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>10</th>
      <td>LONG</td>
      <td>2025-11-10</td>
      <td>512</td>
      <td>6772.25</td>
      <td>2025-11-13</td>
      <td>520</td>
      <td>6832.25</td>
      <td>13.682640</td>
      <td>820.958417</td>
      <td>4.00R</td>
      <td>21344.918844</td>
      <td>✅ WIN</td>
    </tr>
    <tr>
      <th>11</th>
      <td>LONG</td>
      <td>2026-01-05</td>
      <td>601</td>
      <td>6937.25</td>
      <td>2026-01-14</td>
      <td>610</td>
      <td>6982.25</td>
      <td>14.229946</td>
      <td>640.347565</td>
      <td>3.00R</td>
      <td>21985.266409</td>
      <td>✅ WIN</td>
    </tr>
  </tbody>
</table>
</div>


    
    ============================================================
                  TRADE SUMMARY BY TYPE
    ============================================================
    
    LONG Trades:
      Total: 12
      Wins: 11 | Losses: 1
      Total PnL: $11,985.27
      Avg Winning R:R: 7.82R
      Avg Losing R:R: -2.00R
    
    SHORT Trades: None
    
    ============================================================
                  STREAK ANALYSIS
    ============================================================
    Maximum Winning Streak: 8 consecutive trades
    Maximum Losing Streak:  1 consecutive trades



```python
## 13. Monthly/Yearly Performance Breakdown
# Create a DataFrame to analyze trades over time
if trade_log:
    trade_analysis_df = pd.DataFrame(trade_log)
    
    # Calculate cumulative PnL
    trade_analysis_df['Cumulative_PnL'] = trade_analysis_df['PnL'].cumsum()
    
    # Plot cumulative PnL by trade number
    plt.figure(figsize=(14, 6))
    
    colors = ['green' if x > 0 else 'red' for x in trade_analysis_df['PnL']]
    
    plt.bar(range(len(trade_analysis_df)), trade_analysis_df['PnL'], color=colors, alpha=0.7, label='Trade PnL')
    plt.plot(range(len(trade_analysis_df)), trade_analysis_df['Cumulative_PnL'], 
             color='blue', linewidth=2, marker='o', markersize=4, label='Cumulative PnL')
    plt.axhline(y=0, color='black', linestyle='-', linewidth=1)
    
    plt.title('Individual Trade PnL and Cumulative PnL (Full Dataset)', fontsize=16)
    plt.xlabel('Trade Number')
    plt.ylabel('PnL ($)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()
    
    # Long vs Short performance
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Long trades PnL distribution
    long_pnls = [t['PnL'] for t in trade_log if t['Type'] == 'LONG' and 'PnL' in t]
    if long_pnls:
        axes[0].hist(long_pnls, bins=20, color='green', alpha=0.7, edgecolor='black')
        axes[0].axvline(x=0, color='red', linestyle='--', linewidth=2)
        axes[0].set_title(f'Long Trades PnL Distribution\n(n={len(long_pnls)}, Total=${sum(long_pnls):,.2f})')
        axes[0].set_xlabel('PnL ($)')
        axes[0].set_ylabel('Frequency')
        axes[0].grid(True, alpha=0.3)
    
    # Short trades PnL distribution
    short_pnls = [t['PnL'] for t in trade_log if t['Type'] == 'SHORT' and 'PnL' in t]
    if short_pnls:
        axes[1].hist(short_pnls, bins=20, color='magenta', alpha=0.7, edgecolor='black')
        axes[1].axvline(x=0, color='red', linestyle='--', linewidth=2)
        axes[1].set_title(f'Short Trades PnL Distribution\n(n={len(short_pnls)}, Total=${sum(short_pnls):,.2f})')
        axes[1].set_xlabel('PnL ($)')
        axes[1].set_ylabel('Frequency')
        axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
else:
    print("No trades to analyze.")
```


    
![png](output_13_0.png)
    



    
![png](output_13_1.png)
    



```python

```
